#!/bin/bash

g++ -o writing writing.cpp

./writing
